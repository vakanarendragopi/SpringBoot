package com.cts.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.cts.model.Employee;

@RestController
public class TestController {

	@Autowired
	private RestTemplate restTemplate;
	
	@GetMapping("/test")
	public Employee test() {
		
//		ResponseEntity<Employee> res = restTemplate.exchange("http://localhost:8000/welcome", RequestMethod.GET,null,new ParameterizedTypeReference<Employee>() {
//        });
		Employee emp = restTemplate.getForObject("http://eureka_client_1/welcome", Employee.class);
		return emp;
	}
	
	@GetMapping("/gopi")
	public String home() {
		return "Home_Client";
	}
}
