package com.cts.BootPoject_1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BootPoject1Application {

	public static void main(String[] args) {
		SpringApplication.run(BootPoject1Application.class, args);
	}

}
