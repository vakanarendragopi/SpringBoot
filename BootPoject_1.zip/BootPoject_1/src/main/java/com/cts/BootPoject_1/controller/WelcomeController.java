package com.cts.BootPoject_1.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cts.BootPoject_1.model.User;
import com.cts.BootPoject_1.service.UserService;

@RestController
public class WelcomeController {

	@Autowired
	private UserService service;
	
	@RequestMapping("/welcome")
	public String getStarted() {
		return "WelCome";
	}
	
	@RequestMapping("/user")
	public User getUser() {
		return service.getUser();
	}
}
