package com.cts.BootPoject_1.dao;

import com.cts.BootPoject_1.model.User;

public interface UserDAO {
	public User getUser();
}
