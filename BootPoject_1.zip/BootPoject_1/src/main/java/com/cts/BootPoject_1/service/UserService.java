package com.cts.BootPoject_1.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.BootPoject_1.dao.UserDAOImpl;
import com.cts.BootPoject_1.model.User;

@Service
public class UserService {

	@Autowired
	private UserDAOImpl dao;
	
	public User getUser() {
		return dao.getUser();
	}
}
