package com.cts.BootPoject_1.dao;

import org.springframework.stereotype.Repository;

import com.cts.BootPoject_1.model.User;

@Repository
public class UserDAOImpl implements UserDAO{

	public User getUser() {
		return new User(1,"Gopi");
	}

}
