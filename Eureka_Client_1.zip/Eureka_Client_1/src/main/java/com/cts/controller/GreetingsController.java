package com.cts.controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cts.model.Employee;

@RestController
public class GreetingsController {

	@Autowired
	private Employee emp;
	
	@GetMapping("/welcome")
	public Employee welcome() {
		emp.setName("Gopi");
		return emp;
	}
	
}
